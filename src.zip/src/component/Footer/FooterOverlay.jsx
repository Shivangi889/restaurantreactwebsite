import React from 'react';

import './FooterOverlay.css';

const FooterOverlay = () =>{ return(
  <div>
    FooterOverlay
  </div>
);
};
export default FooterOverlay;