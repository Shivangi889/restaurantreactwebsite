import React from 'react';

import './Menuitem.css';

const Menuitem = () =>{ return(
  <div>
    MenuItem
  </div>
);
};
export default Menuitem;