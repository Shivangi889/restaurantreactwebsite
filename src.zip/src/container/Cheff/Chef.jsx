import React from 'react';

import './Chef.css';

const Chef = () => {
  return(
  <div>
    Chef
  </div>
);
  };
export default Chef;