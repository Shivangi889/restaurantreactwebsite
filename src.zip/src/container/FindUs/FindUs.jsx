import React from 'react';

const FindUs = () => {
  return (
    <div>
      FindUs
    </div>
  );
};
export default FindUs;