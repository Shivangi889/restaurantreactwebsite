import React from 'react';

import './food.css';

const Food = () => {
  return (
    <div>
      Gallery
    </div>
  );
};
export default Food;