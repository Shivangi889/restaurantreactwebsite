import React from 'react';

import './Intro.css';

const Intro = () => {
  return (
    <div>
      Intro
    </div>
  );
};
export default Intro;