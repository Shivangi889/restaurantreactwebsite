import React from 'react';

import './Laurels.css';

const Laurels = () => {
  return (
    <div>
      Laurels
    </div>
  );
};
export default Laurels;