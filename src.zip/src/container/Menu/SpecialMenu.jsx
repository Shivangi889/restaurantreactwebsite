 import React from 'react';
// import images from '../../constants/images.js'
 import { SubHeading,Menuitem } from '../../component';
// import {data} from '../../constants/data'
export default function SpecialMenu() {
  return (
    <div className=''>
    </div>
  );
}