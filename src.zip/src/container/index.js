import AboutUs from './AboutUs/AboutUs';
import Cheff from './Cheff/Chef';
import FindUs from './FindUs/FindUs';
import Footer from './Footer/footer';
import Food from './Food/food';
import Header from './Header/Header';
import Intro from './Intro/intro';
import Laurels from './Laurels/Laurels';
 import SpecialMenu from './Menu/SpecialMenu';

export  {
  AboutUs,
  Cheff,
  FindUs,
  Footer,
  Food,
  Header,
  Intro,
  Laurels,
 SpecialMenu,
};